const nodemailer = require('nodemailer');
// Configure and send Mail
module.exports = {

    notify : () => {

        let transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'pruebaalarmalg@gmail.com',
                pass: 'smtmtvihqflcceae'
            }
        });
        
        var mailOptions = {
            from: 'Node Monitoring',
            to: 'pruebaalarmalg@gmail.com',
            subject: '¡Caida de web!',
            html: "<h2><b>WARNING❗❗❗</b></h2> <br> <h3><b> la pagina de accesorios de lg ha caido!</b></h3>"
        };
        
        transporter.sendMail(mailOptions, function(error, info){
            if (error) {
                console.log(error);
            } else {
                console.log('Email sent: ' + info.response);
            }
        });
    }
}
